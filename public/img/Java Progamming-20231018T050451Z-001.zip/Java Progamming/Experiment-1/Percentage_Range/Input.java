import java.lang.*;
import java.util.*;

class Input
{
   public static void main(String User[])
   {
     char a;

     Scanner sc = new Scanner(System.in);
     
     System.out.println("Enter the Grade to get the pecentage range: ");
     a = sc.next().charAt(0);
     System.out.println("Grade :- "+a);

     switch(a)
     {
       case 'A':
       {
         System.out.println("This Student got grade "+a+"\n percentage Range : 91-100");
         break;
       }

       case 'B':
       {
         System.out.println("This Student got grade "+a+"\n percentage Range : 81-90");
         break;
       }
        
       case 'C':
       {
         System.out.println("This Student got grade "+a+"\n percentage Range : 71-80");
         break;
       }
       
       case 'D':
       {
         System.out.println("This Student got grade "+a+"\n percentage Range : 61-70");
         break;
       }

       case 'F':
       {
         System.out.println("This Student got grade "+a+"\n percentage Range : 0-60");
         break;
       }


     }
   }
}
