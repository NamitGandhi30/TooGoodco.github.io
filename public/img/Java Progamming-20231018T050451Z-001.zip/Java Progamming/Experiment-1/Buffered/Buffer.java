import java.lang.*;
import java.io.*;

class Buffer
{ 

  public static void main(String buf[])throws IOException
  {
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(isr);
     
    int p,c,m,Total;
    System.out.println("Enter the marks of the student in Physics, Chemistry & maths:");

//Physics
    System.out.print("Enter the marks of physics: ");
    p = Integer.parseInt(br.readLine());
    System.out.print("\n");

//Chemistry
    System.out.print("Enter the marks of Chemistry: ");
    c = Integer.parseInt(br.readLine());
    System.out.print("\n");

//Maths 
    System.out.print("Enter the marks of Maths: ");
    m = Integer.parseInt(br.readLine());
    System.out.print("\n");

   Total = p+c+m;
   //cd /home/student/Desktop/C31_Suban/Buffered
System.out.println("Total Marks: " + Total);

   if(m>=60 && p>=50 && c>=40 && Total>=200)
   {
    System.out.println("Student is Eligible for Admission");
     }

    else
    {
       System.out.println("Student is not Eligible for Admission");
    }
    
  } 
}
