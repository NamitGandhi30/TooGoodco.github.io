import java.util.*;

class StudentMarks {
    public static void main(String SM[])
    {
        Scanner sc = new Scanner(System.in);

        int Total,High;
        int n,i,count;
        count = 0;Total =0 ;

        // System.out.print("\nEnter the Number of Subject: ");
        // n = sc.nextInt();

        int Sub[] = new int[5];
        // len = Sub.lenght();
        
        System.out.print("\nEnter the Marks of Subject: \n");
        for(i=0;i<5;i++)
        {
          Sub[i] = sc.nextInt();
          count++;
        }
        
        High = Sub[0];
        for(i=0;i<count;i++)
        {
            Total += Sub[i];
            if(High < Sub[i])
            {
               High = Sub[i];
            }
        }
        System.out.print("The Total Marks is: "+Total+" .\n");
        System.out.print("The Highest Marks is: "+High+" .\n");

        sc.close();
    }
}
