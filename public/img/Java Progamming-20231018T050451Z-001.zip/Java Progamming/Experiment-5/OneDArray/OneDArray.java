import java.lang.*;
import java.io.*;
import java.util.*;

class OneDArray
{ 
  public static void main(String Arg[]) 
  {
    int n,eveni,oddi,i;
    eveni = 0;oddi = 0;
    Scanner sc = new Scanner(System.in);

    System.out.println("Enter the Size of the Array: ");
    n = sc.nextInt();
    
    int evenOdd[] = new int[n];
    int even[] = new int[20];
    int odd[] = new int[20];

    for(i=0;i<n;i++)
    {
     evenOdd[i] = sc.nextInt();
    }

    for(i=0;i<n;i++)
    {
      if(evenOdd[i]%2==0)
       {
         even[i] = evenOdd[i];
         eveni++;
        }

     else if(evenOdd[i]%2!=0)
       {
           odd[i] = evenOdd[i];
          oddi++;
        }
    }


    System.out.println("The Number of Even number: "+eveni+"\n The Even Numbers are: \n");
    for(i=0;i<eveni;i++)
    {
     System.out.print(even[i] +" ");
    }

    System.out.println("The Number of Odd number: "+oddi);
    for(i=0;i<oddi;i++)
    {
     System.out.print(odd[i] +" ");
    }
  }
}

//cd /home/student/Desktop/C31_Suban/java/OneDArray
