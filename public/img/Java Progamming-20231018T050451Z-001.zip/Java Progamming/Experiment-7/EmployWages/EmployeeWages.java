import java.util.Scanner;

class Employee {
    String name;
    String id;
    double hoursWorked;

    // Constructor
    public Employee(String name, String id, double hoursWorked) {
        this.name = name;
        this.id = id;
        this.hoursWorked = hoursWorked;
    }

    // Method to calculate wages
    public double calculateWages() {
        return hoursWorked * 100;  // Rs. 100 per hour
    }
}

public class EmployeeWages {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an array of Employee objects to store employee details
        Employee[] employees = new Employee[5];

        // Input details for 5 employees
        for (int i = 0; i < 1; i++) {
            System.out.println("Enter details for Employee " + (i + 1) + ":");
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("ID: ");
            String id = scanner.nextLine();
            System.out.print("Hours worked: ");
            double hoursWorked = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character

            // Create an Employee object and store it in the array
            employees[i] = new Employee(name, id, hoursWorked);
        }

        // Display the information in tabular format
        System.out.println("\nEmployee Details:");
        System.out.printf("%-10s%-20s%-15s%-15s\n", "Id", "Name", "No. of Hours", "Wages (Rs.)");
        System.out.println("==============================================================");
        for (int i = 0; i < 1; i++) {
            System.out.printf("%-10s%-20s%-15s%-15s\n", employees[i].id, employees[i].name, employees[i].hoursWorked, employees[i].calculateWages());
        }

        scanner.close();
    }
}


///Users/suban0408/Desktop/EmployeeWages.java