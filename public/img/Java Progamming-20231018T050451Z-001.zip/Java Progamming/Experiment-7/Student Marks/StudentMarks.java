import java.lang.*;
import java.io.*;
import java.util.*;

class StudMark {
    int Phy,Chem,Maths;

    // Constructor
    public StudMark(int Phy, int Chem, int Maths)
    {
        this.Phy = Phy;
        this.Chem = Chem;
        this.Maths = Maths;
    }
}

class StudentMarks
{
   public static void main(String SM[])
   {
     Scanner scanner = new Scanner(System.in);

     int phy,chem,maths,i;
     StudMark [] Sm = new StudMark[5];
     int [] Total = new int[5];

     for (i = 0; i < 2; i++)
    {
      System.out.println("\nEnter details for Student -" + (i + 1) + ":");
      
      System.out.print("Physics : "); 
      phy = scanner.nextInt();
      
      System.out.print("Chemistry : "); 
      chem = scanner.nextInt();

      System.out.print("Mathematics : "); 
      maths = scanner.nextInt();

      Sm[i] = new StudMark(phy,chem,maths);
      Total[i] = phy+chem+maths;
    }

int temp = Total[0];
int r = 0;
  for(i=0;i<2;i++)
 {
    System.out.println("\nTotals Marks for Student -" + (i + 1) + ": "+Total[i]);
    if(temp < Total[i])
   {
     temp = Total[i];
     r = i;
   }
 }

System.out.println("\nThe Student- "+r+1+" got the Highest Total Marks: "+temp+".");
   }
}