import java.lang.*;
import java.io.*;
import java.util.*;

class EmployClass
{

 String post,name;
 int id;
 double salary;
  void getData()
  {
   Scanner sc = new Scanner(System.in);

   System.out.print("Enter the Name of the Eployee: ");
   name = sc.nextLine();

   System.out.print("Enter the Post of the Eployee: ");
   post = sc.nextLine();

   System.out.print("Enter the ID of the Eployee: ");
   id = sc.nextInt();

   
   System.out.print("Enter the Salary of the Eployee: ");
   salary = sc.nextDouble();
  }

  void print()
  {
    System.out.print("\nEmployee Details:\n");
    System.out.print("Name: "+ name +".\n");
    System.out.print("ID: "+ id +".\n");
    System.out.print("Salary: "+ salary +".\n");
    System.out.print("Post: "+ post +".\n");
  }
 

  public static void main(String Employ[])
  {
    EmployClass Ec = new EmployClass();
    
    Ec.getData();
    Ec.print();
  }
}
//cd /home/student/Desktop/C31_Suban/java/EmployClass
