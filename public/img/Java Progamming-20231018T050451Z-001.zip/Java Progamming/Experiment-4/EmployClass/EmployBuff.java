import java.lang.*;
import java.io.*;
import java.util.*;

class EmployBuff
{

 String post,name;
 int id;
 double salary;
  void getData()throws IOException
  {
   InputStreamReader isr = new InputStreamReader(System.in);
   BufferedReader br = new BufferedReader(isr);

   System.out.print("Enter the Name of the Eployee: ");
   name = br.readLine();

   System.out.print("Enter the Post of the Eployee: ");
   post = br.readLine();

   System.out.print("Enter the ID of the Eployee: ");
   id = Integer.parseInt(br.readLine());

   
   System.out.print("Enter the Salary of the Eployee: ");
   salary = Double.parseDouble(br.readLine());
  }

  void print()
  {
    System.out.print("\nEmployee Details:\n");
    System.out.print("Name: "+ name +".\n");
    System.out.print("ID: "+ id +".\n");
    System.out.print("Salary: "+ salary +".\n");
    System.out.print("Post: "+ post +".\n");
  }
 

  public static void main(String Employ[])throws IOException
  {
    EmployClass Ec = new EmployClass();
    
    Ec.getData();
    Ec.print();
  }
}
//cd /home/student/Desktop/C31_Suban/java/EmployBuff
