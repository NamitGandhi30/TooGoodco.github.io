import java.lang.*;
import java.io.*;
import java.util.*;

class CondTwoClass
{
   public static void main(String TwoClass[])
  {
    int MAX;
    Cond cd = new Cond();
    cd.getData();
    MAX = cd.max();
    System.out.println("The Largest Number is: "+ MAX +".");
   
  }
  
}

class Cond
{
  int a,b,c,largest;

  void getData()
  {
   Scanner sc = new Scanner(System.in);
   
   System.out.println("Enter the three Numbers: ");
   System.out.print("Enter the Number-1: ");
   a = sc.nextInt();
   
   System.out.print("Enter the Number-2: ");
   b = sc.nextInt();

   System.out.print("Enter the Number-3: ");
   c = sc.nextInt();
  }

  int max()
  {
     largest = (a>b)?(a>c?a:c):(b>c?b:c);
     return largest;
   }
}
//cd /home/student/Desktop/C31_Suban/java/CondTwoClass
