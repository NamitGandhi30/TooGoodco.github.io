import java.util.*;

class Palindrome
{
    public static void main(String Palin[])
    {
      Scanner sc = new Scanner(System.in);
       
      String palind;
      int i,len,flag;
      flag =0;

      System.out.println("\nEnter the String:");
      palind = sc.nextLine();
      len = palind.length();

      for(i=0;i<len;i++)
      {
        if(palind.charAt(i) != palind.charAt(len-i-1))
        {
          flag++;
          break;
        }
      }

      if(flag != 0)
      {
         System.out.println("\nThe Given String is not Palindrome.\n");
      }

      else if(flag == 0)
      {
         System.out.println("\nThe Given String is Palindrome.\n");
      }

      sc.close();
    }
}

//  cd  /Users/complab301pc23/Desktop/C31_Suban/Palindrome