import java.lang.*;
import java.io.*;
import java.util.*;


class StringCheckOne
{
   
    public static void main(String Palin[])
    {
      Scanner sc = new Scanner(System.in);
      String str;
      int i,Up,Lo,Sp,Bs,D;
      Up = 0;Lo = 0;Sp = 0;Bs = 0;D = 0;

      System.out.println("\nEnter the String: ");
      str = sc.nextLine();

      for(i=0;i<str.length();i++)
      {
        if(str.charAt(i) >= 'A' && str.charAt(i)<= 'Z')
        {
           Up++;
        }

        if(str.charAt(i) >= 'a' && str.charAt(i)<= 'z')
        {
           Lo++;
        }

        if((str.charAt(i) >= '!' && str.charAt(i)<= '/') || 
           (str.charAt(i) >= ':' && str.charAt(i)<= '@') || 
           (str.charAt(i) >= '[' && str.charAt(i)<= '`') || 
           (str.charAt(i) >= '{' && str.charAt(i)<= '~')    )
        {
           Sp++;
        }

        if(str.charAt(i) == ' ')
        {
           Bs++;
        }

        if(str.charAt(i) >= '0' && str.charAt(i)<= '9')
        {
           D++;
        }
      }

      System.out.println("The Number of Upper Case in the String is: "+Up+".");
      System.out.println("The Number of Lower Case in the String is: "+Lo+".");
      System.out.println("The Number of Special Character in the String is: "+Sp+".");
      System.out.println("The Number of Blank Space in the String is: "+Bs+".");
      System.out.println("The Number of Digits in the String is: "+D+".");

      sc.close();

    }
 
}

// cd /Users/suban0408/mywork/JAVA