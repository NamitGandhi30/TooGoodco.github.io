import java.util.*;
import java.lang.*;

//STAFF
class Staff {

    Staff(int a, String name, String Add) {
        System.out.println("The code is: " + a);
        System.out.println("The Name is: " + name);
        System.out.println("The Address is: " + Add);
    }

}

// TEACHER
class Teacher extends Staff {

    Teacher(int x, String name, String Add,String Sub, String Class) {
        super(x, name, Add);
        System.out.println("The Subject of the Teacher is: " + Sub);
        System.out.println("The Class of the Teacher is: " + Class);
    }
}

// OFFICER
class Officer extends Staff {
    Officer(int x, String name, String Add,char grade) {
        super(x, name, Add);
       System.out.println("The grade of the officer is: "+grade);
    }
}

// TYPIST
class Typist extends Staff {
    
    Typist(int x, String name, String Add,int speed) {
        super(x, name, Add);
        System.out.println("The Typing Speed of the Typist is : "+speed);
    }
}

// REGULAR
class Regular extends Typist {

    Regular(int x, String name, String Add,int pay,int speed)
    {
      super(x, name, Add,speed);
      System.out.println("The Basic pay of Regular is: "+pay);
    }
}

// AD-HOC
class Ad_Hoc extends Typist {
   Ad_Hoc(int x, String name, String Add,int pay,int speed)
    {
      super(x, name, Add,speed);
      System.out.println("The Basic pay of Regular is: "+pay);
    }
}

class Inheritance {
    public static void main(String arg[])
    {
      Scanner sc = new Scanner(System.in);
      int x,n,speed,pay;
      char Grade;
      String name,Add,Sub,Class;


      do{
      System.out.println("\nWhich Class information do you need to Enter: ");
      System.out.println("1.Teacher  2.Typist  3.Officer  4.Regular  5.Ad-Hoc  6.Exit");
      System.out.print("Enter the Respective Number: ");
      n = sc.nextInt();
 

      switch (n) {
        case 1:
            //Teacher
            System.out.print("Enter the Code of Teacher: ");
            x = sc.nextInt();
            System.out.print("Enter the Name of the Teacher: ");
            name = sc.next();
            System.out.print("Enter the Address of the Teacher: ");
            Add = sc.next();

            System.out.print("Enter the Subject: ");
            Sub = sc.next();
            System.out.print("Enter the Class: ");
            Class = sc.next();

            System.out.println("\nThe Details of the Teacher: ");
            Teacher T1 = new Teacher(x,name,Add,Sub,Class);
            break;

            case 2:
            System.out.print("Enter the Code of Typist: ");
            x = sc.nextInt();
            System.out.print("Enter the Name of the Typist: ");
            name = sc.next();
            System.out.print("Enter the Address of the Typist: ");
            Add = sc.next();

            System.out.print("Enter the Typing Speed of Typist: ");
            speed = sc.nextInt();

            System.out.println("\nThe Details of the Typist: ");
            Typist Ty = new Typist(x,name,Add,speed);

            break;

            case 3:
            System.out.print("Enter the Code of Officer: ");
            x = sc.nextInt();
            System.out.print("Enter the Name of the Officer: ");
            name = sc.next();
            System.out.print("Enter the Address of the Officer: ");
            Add = sc.next();

            System.out.print("Enter the Grade of the officer: ");
            Grade = sc.next().charAt(0);

            System.out.println("\nThe Details of the Officer: ");
            Officer of = new Officer(x,name,Add,Grade);
            break;

            case 4:
            System.out.print("Enter the Code of Regular: ");
            x = sc.nextInt();
            System.out.print("Enter the Name of the Regular: ");
            name = sc.next();
            System.out.print("Enter the Address of the Regular: ");
            Add = sc.next();

            System.out.print("Enter the Basic Pay of the Regular: ");
            pay = sc.nextInt();
            System.out.print("Enter the Speed of the Typing of Reagular: ");
            speed = sc.nextInt();

        
            System.out.println("\nThe Details of Regular is: ");
            Regular reg = new Regular(x,name,Add,pay,speed);
            
            break;

            case 5:
            System.out.print("Enter the Code of Ad-HOC: ");
            x = sc.nextInt();
            System.out.print("Enter the Name of the Ad-HOC: ");
            name = sc.next();
            System.out.print("Enter the Address of the Ad-HOC: ");
            Add = sc.next();

            System.out.print("Enter the Basic Pay of the Ad-HOC: ");
            pay = sc.nextInt();
            System.out.print("Enter the Speed of the Typing of Ad-HOC: ");
            speed = sc.nextInt();

            System.out.println("\nThe Details of Ad-HOC is: ");
            Ad_Hoc Ad = new Ad_Hoc(x,name,Add,pay,speed);
    
            break;

            case 6:
            System.out.println("\nExiting the program!!!");
            break;
        default:
            break;
      }
      
      }while(n!=6);

    }
}