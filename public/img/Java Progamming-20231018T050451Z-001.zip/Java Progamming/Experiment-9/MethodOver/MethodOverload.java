import java.util.*;

class Area
{
   double AreaShape(int l, int b)
  {
   double Areas = l*b;
   return Areas;
  }

   double AreaShape(int l)
  {
   double Areas = l*l;
   return Areas;
  }

   double AreaShape(float r)
  {
   double Areas = 3.1456*r*r;
   return Areas;
  }
}


class MethodOverload
{
    public static void main(String Mo[])
   {
     Scanner sc = new Scanner(System.in);

     Area A = new Area();    

     int n,l,b;
     float r;
     double area;
     System.out.println("The Shapes to find the Area are:\n1.Rectangle 2.Square 3.Circle\nEnter the Number: ");
     n = sc.nextInt();

      switch(n)
     {
       case 1:
       System.out.print("Enter the Lenght: ");
       l = sc.nextInt();

       System.out.print("Enter the Breadth: ");
       b = sc.nextInt();

       area = A.AreaShape(l,b);

       System.out.println("Area of the Rectangle : "+area);
       break;

       case 2:
       System.out.print("Enter the Side lenght : ");
       l = sc.nextInt();

       area = A.AreaShape(l);
       System.out.println("Area of the Square : "+area);
       break;

       case 3:
       System.out.println("Enter the Radius : ");
       r = sc.nextFloat();

       area = A.AreaShape(r);
       System.out.println("Area of the Square : "+area);
       break;

       default:
       System.out.println("Enter the Valid number!!!");
       break;
     }
   }
}

// cd //home/student/Desktop/C31_Suban/java/MethodOver
