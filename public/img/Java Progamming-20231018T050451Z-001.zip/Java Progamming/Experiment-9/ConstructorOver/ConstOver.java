import java.util.*;

class Area
{
  int x,y;
  float z;

   Area(int l, int b)
  {
   x = l;
   y = b;
  }

   Area(int l)
  {
   x = l;
  }

   Area(float r)
  {
   z = r;
  }

   public double AreaSq()
  {
   return x*x;
  }

  public double AreaRect()
  {
   return x*y;
  }

  public double AreaCir()
  {
   return 3.1456*z*z;
  }
}


class ConstOver
{
    public static void main(String Mo[])
   {
     Scanner sc = new Scanner(System.in); 

     int n,l,b;
     float r;
     double area;
     System.out.println("The Shapes to find the Area are:\n1.Rectangle 2.Square 3.Circle\nEnter the Number: ");
     n = sc.nextInt();

      switch(n)
     {
       case 1:
       System.out.print("Enter the Lenght: ");
       l = sc.nextInt();

       System.out.print("Enter the Breadth: ");
       b = sc.nextInt();

       Area A = new Area(l,b);

       System.out.println("Area of the Rectangle : "+A.AreaRect());
       break;

       case 2:
       System.out.print("Enter the Side lenght : ");
       l = sc.nextInt();

       Area A1 = new Area(l);
       System.out.println("Area of the Square : "+A1.AreaSq());
       break;

       case 3:
       System.out.println("Enter the Radius : ");
       r = sc.nextFloat();

       Area A2 = new Area(r);
       System.out.println("Area of the Square : "+A2.AreaCir());
       break;

       default:
       System.out.println("Enter the Valid number!!!");
       break;
     }
   }
}

// cd //home/student/Desktop/C31_Suban/java/ConstructorOver
