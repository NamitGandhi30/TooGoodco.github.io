import java.util.*;
import java.lang.*;

public class INBuilt_Exception {
    public static void main(String[] args) {
       
       Scanner sc = new Scanner(System.in);
        String text = null;
        int n,d,len,res,p;

        int [] Arr = {1,2,3};


        //EXCEPTION - 1
        try{
          System.out.print("Enter the Numerator: ");
          n =sc.nextInt();

          System.out.print("Enter the Denominator: ");
          d =sc.nextInt();
          res = n/d;
        }
        catch(Exception e)
        {
           System.out.println("\nDue to some Exception Error Occured");
           System.out.println("Reason: "+e);
        }


        //EXCEPTION - 2
         try{
          p = Arr[3];
          System.out.println("The element: "+p);
        }
        catch(Exception e)
        {
           System.out.println("\nDue to some Exception Error Occured");
           System.out.println("Reason: "+e);
        }


        //EXCEPTION - 3
        try{
          len = text.length();
          System.out.println("The lenght of string is: "+len);
        }
        catch(Exception e)
        {
           System.out.println("\nDue to some Exception Error Occured");
           System.out.println("Reason: "+e);
        }

                System.out.println("\nExiting the Program!!!\n");
                sc.close();
    }
       
}
