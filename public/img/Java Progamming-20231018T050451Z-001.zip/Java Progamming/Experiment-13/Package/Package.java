

class Addition {
    public static double add(double num1, double num2) {
        return num1 + num2;
    }
}

class Subtraction {
    public static double subtract(double num1, double num2) {
        return num1 - num2;
    }
}

class Multiplication {
    public static double multiply(double num1, double num2) {
        return num1 * num2;
    }
}

class Division {

    public static double divide(double num1, double num2) {
        if (num2 == 0) {
            throw new ArithmeticException("Division by zero is not allowed");
        }
        return num1 / num2;
    }
}

public class Package {
    
    public static void main(String[] args) {
        double num1 = 10.0;
        double num2 = 5.0;

        // Perform addition
        double resultAddition = Addition.add(num1, num2);
        System.out.println("Addition: " + resultAddition);

        // Perform subtraction
        double resultSubtraction = Subtraction.subtract(num1, num2);
        System.out.println("Subtraction: " + resultSubtraction);

        // Perform multiplication
        double resultMultiplication = Multiplication.multiply(num1, num2);
        System.out.println("Multiplication: " + resultMultiplication);

        // Perform division
        try {
            double resultDivision = Division.divide(num1, num2);
            System.out.println("Division: " + resultDivision);
        } catch (ArithmeticException e) {
            System.out.println("Division by zero is not allowed.");
        }
    }
}

///Users/suban0408/MyWork/SEM-3/JAVA/JAVAC/math_operations/Package.java