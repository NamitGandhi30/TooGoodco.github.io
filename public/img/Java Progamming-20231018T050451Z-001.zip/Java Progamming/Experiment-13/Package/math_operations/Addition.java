package math_operations;


public class Addition {
    public static double add(double num1, double num2) {
        return num1 + num2;
    }
}