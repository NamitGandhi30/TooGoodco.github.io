package math_operations;


public class Subtraction {
    public static double subtract(double num1, double num2) {
        return num1 - num2;
    }
}