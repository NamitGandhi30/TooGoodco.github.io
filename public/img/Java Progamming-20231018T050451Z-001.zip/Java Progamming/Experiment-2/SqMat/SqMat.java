import java.lang.*;

class SqMat
{   
   public static void main(String Mat[])
   {
    int i,j,k;
    k=0;

    System.out.println("This is the Square of the Number from 1-25 in table:");
    for(i=0;i<5;i++)
    {
      for(j=0;j<5;j++)
      {
        k++;
        System.out.print(k*k+ " ");
       }
       System.out.print("\n");
     }   


   }

}
