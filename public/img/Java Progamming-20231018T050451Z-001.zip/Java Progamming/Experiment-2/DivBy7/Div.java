import java.lang.*;

class Div
{

   public static void main(String Divi[])
  {
   int i,sum,count;
   sum=0;
   count=0;
   
   System.out.print("This is the number Divisible by 7 from 100-200:\n");
   for(i=100;i<200;i++)
    {
      if(i%7==0)
      {
       System.out.print(i+" ");
       sum=sum+i;
       count++;
      }

     }
   System.out.print("\n\nThis is sum of the number which is Divisible by 7: "+ sum+"\n");
   System.out.print("This is number of Term which are Divisible by 7: "+ count+"\n");
  }


}
