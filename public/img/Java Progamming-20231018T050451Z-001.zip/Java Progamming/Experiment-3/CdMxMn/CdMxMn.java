import java.lang.*;

class CdMxMn
{
  
   public static void main(String num[])
   {
     int a = Integer.parseInt(num[0]);
      int b = Integer.parseInt(num[1]);
      int c = Integer.parseInt(num[2]);
     System.out.println("The Maximum And Minimum of Three Number: " +a+", "+b+" & "+c); 
   
//Maximum
      if((a>b) && (a>c))
      {
       System.out.println("The Number " +a+ " is Greatest");
       }
       
    else if((b>a) && (b>c))
      {
       System.out.println("The Number " +b+ " is Greatest");
       }

      else
      {
        System.out.println("The Number " +c+ " is Greatest");
      }


//Minimum
      if((a<b) && (a<c))
      {
       System.out.println("The Number " +a+ " is Smallest");
       }
       
    else if((b<a) && (b<c))
      {
       System.out.println("The Number " +b+ " is Smallest");
       }

      else
      {
        System.out.println("The Number " +c+ " is Smallest");
      }
 
 
   }

}
