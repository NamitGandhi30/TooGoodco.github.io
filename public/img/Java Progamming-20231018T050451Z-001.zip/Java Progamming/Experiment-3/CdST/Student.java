import java.lang.*;

class Student
{
  public static void main(String stud[])
  {
   System.out.println("This is the detail of the student:");

   System.out.print("Name: "+ stud[0] + "\nRoll no.: " + stud[1]  + "\nClass: " + stud[2] + "\nSemester: " + stud[3]);
  }
  
}
