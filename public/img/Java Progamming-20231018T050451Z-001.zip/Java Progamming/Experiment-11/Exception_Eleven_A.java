import java.util.*;

class InvalidNumberException extends Exception {
    @Override
    public String getMessage() {
        return "The Number is not 5, 6, or 7";
    }
}

public class Exception_Eleven_A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n, y;
        System.out.print("Enter the Number: ");
        n = sc.nextInt();

        try {
            y = number(n);
            System.out.println("You Entered the valid Number: " + n);
        } catch (InvalidNumberException e) {
            System.out.println("InvalidNumberException: " + e.getMessage());
        }

        sc.close();
    }

    public static int number(int n) throws InvalidNumberException {
        if (n != 5 && n != 6 && n != 7) {
            throw new InvalidNumberException();
        }
        return n;
    }
}
