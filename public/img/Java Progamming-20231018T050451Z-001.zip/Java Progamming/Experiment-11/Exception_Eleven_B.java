import java.util.*; 

class PayOutOfBounds extends Exception {
    public PayOutOfBounds(String message) {
        super(message);
    }
}

// Superintendent class
class Superintendent {
    private double basicPay;

    public Superintendent(double basicPay) {
        this.basicPay = basicPay;
    }

    public void verifyPay() throws PayOutOfBounds {
        if (basicPay < 25000 || basicPay > 50000) {
            throw new PayOutOfBounds("Basic pay is out of bounds: " + basicPay);
        } else {
            System.out.println("Basic pay is within the acceptable range: " + basicPay);
        }
    }
}

public class Exception_Eleven_B {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the Salary of the Superintendent: ");
        int n = sc.nextInt();
        try {
            Superintendent superintendent = new Superintendent(n); // Replace with the desired basic pay
            superintendent.verifyPay();
        } catch (PayOutOfBounds e) {
            System.out.println("PayOutOfBounds Exception: " + e.getMessage());
        }
    }
}
