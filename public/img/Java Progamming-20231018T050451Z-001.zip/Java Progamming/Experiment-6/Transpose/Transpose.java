import java.lang.*;
import java.util.*;

class Transpose
{
   public static void main(String Sq[])
   {
   	
   	Scanner sc = new Scanner(System.in);
   	
   	int i,j,m,n;
   	
   	System.out.print("Enter the Number of Rows and Coloumn: ");
   	m = sc.nextInt();
   	n = sc.nextInt();
   	
   
   	int [][]p = new int[m][n];
   	
   		//Taking the Element of Matrix
   		System.out.println("Enter the Elements of Matrix: ");
   		for(i=0;i<m;i++)
   		{
   			for(j=0;j<n;j++)
   			{
   				p[i][j] = sc.nextInt();
   			}
   		}
   		
   		
   		//Calculating sum of Diagonal Element
        System.out.println("The Transpose Matrix is: ");			
   		for(i=0;i<n;i++)
   		{
   			for(j=0;j<m;j++)
   			{
   				System.out.print(p[j][i]+" ");			
            }
            System.out.print("\n");			
        }
   	
   	sc.close();
   	
   }
}
// cd  /Users/complab301pc23/Desktop/C31_Suban/Transpose  
// javac Transpose.java
// java Transpose
