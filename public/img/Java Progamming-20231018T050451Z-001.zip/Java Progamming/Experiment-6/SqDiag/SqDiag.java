import java.lang.*;
import java.util.*;

class SqDiag
{
   public static void main(String Sq[])
   {
   	
   	Scanner sc = new Scanner(System.in);
   	
   	int i,j,m,n,sum;
   	sum =0;
   	
   	System.out.print("Enter the Number of Rows and Coloumn: ");
   	m = sc.nextInt();
   	n = sc.nextInt();
   	
   
   	int [][]p = new int[m][n];
   	
   	if(m==n)
   	{
   		//Taking the Element of Matrix
   		System.out.println("Enter the Elements of Matrix: ");
   		for(i=0;i<m;i++)
   		{
   			for(j=0;j<n;j++)
   			{
   				p[i][j] = sc.nextInt();
   			}
   		}
   		
   		
   		//Calculating sum of Diagonal Element
   		for(i=0;i<m;i++)
   		{
   			for(j=0;j<n;j++)
   			{
   				if(i==j)
   				{
   				sum += p[i][j];
                }  			
   			}
   		}
   		
   		System.out.print("The Sum of The Diagonal Elements is: "+sum+".\n");
   		
   	}
   	
   	else
   	{
                System.out.println("Enter the Elements of Matrix: ");
   		for(i=0;i<m;i++)
   		{
   			for(j=0;j<n;j++)
   			{
   				p[i][j] = sc.nextInt();
   			}
   		}
   		System.out.print("\nEnter the Valid Number of Row and Coloumn!!! (row == Col)\n");
   	}
   	
   	sc.close();
   	
   }

}

//  cd  /Users/complab301pc23/Desktop/C31_Suban/SqDiag